const Discord = require('discord.js')

module.exports.run = async (client, message, args) => {
let avatar = client.user.displayAvatarURL
let tutorial = new Discord.RichEmbed()
.setAuthor(`Bantuan Bot SpiritSMP`)
.setThumbnail(client.user.displayAvatarURL)
.addField("―――――― :headphones: Music :headphones: ――――――", '`s!play, s!stop, s!pause, s!skip, \ns!np, s!volume, s!pause, s!join, \ns!resume, s!stop, s!leave, s!queue`')
.addField("―――――― :symbols: Utils :symbols: ――――――", '`s!ascii, s!avatar, s!autonick, s!autonick off,\n s!autonick on, s!autonick previous, s!ping, \ns!coins, s!level`')
.addField("―――――― :satellite: Core :satellite: ――――――", '`s!help, s!info, s!afk, s!bugreport,\n s!stats, s!invite, s!prefix, info`')
.addField("―――――― :underage: Nsfw :underage: ――――――", '`s!nsfw, s!hentai, s!ass, s!boobs,\n s!neko,`')
.addField("―――――― :bomb: Fun :bomb: ――――――", '`s!joke, s!meme, s!8ball, s!dog, \ns!cat, s!pig, s!chameleon, s!quiz, \ns!anime, s!animemes, s!get, s!flip,\n s!gif, s!emoji, s!bunny`')
.addField("―――――― :tools: Dev :tools: ――――――", '`s!reload, s!restart, s!eval`')
.addField("―――――― :wrench: Mod :wrench: ――――――", '`s!ban, s!mute, s!kick, s!mute,\n s!purge, s!warn, s!say, s!saybd, \ns!dm, s!welcome`')
.addField("―――――― :bookmark: Info :bookmark: ――――――", '`s!stats, s!serverinfo, s!profile, s!stats, s!mcserver  `')
.addField("―――――― :desert: Picture :desert: ――――――", '`s!cat, s!dog, s!panda, s!chameleon, s!photograph, s!pig, s!bunny, s!hug, s!slap `')
message.channel.send(tutorial).then(msg => msg.react('😊').then(msg => msg.react('😊')).then(msg => msg.react('😊')).then(msg => msg.react('😊')))
}
